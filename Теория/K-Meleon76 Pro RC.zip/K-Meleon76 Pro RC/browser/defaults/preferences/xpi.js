//makes possible to install xpi-addons for Firefox to K-Meleon
pref("kmeleon.install_firefox_extension", true);
