pref("kmeleon.general.toolbars_locked", true);
pref("kmeleon.display.maximized", true);
pref("kmeleon.display.hideTitleBar", false);

pref("kmeleon.toolband.Menu.break", 0);
pref("kmeleon.toolband.Menu.index", 0);
pref("kmeleon.toolband.Menu.size", 885);
pref("kmeleon.toolband.Menu.visibility", false);

pref("kmeleon.toolband.KMrestart2.break", 1);
pref("kmeleon.toolband.KMrestart2.index", 1);
pref("kmeleon.toolband.KMrestart2.size", 36);
pref("kmeleon.toolband.KMrestart2.visibility", true);

pref("kmeleon.toolband.&Main Bar.break", 0);
pref("kmeleon.toolband.&Main Bar.index", 2);
//pref("kmeleon.toolband.&Main Bar.size", 128);
pref("kmeleon.toolband.&Main Bar.visibility", true);

pref("kmeleon.toolband.Throbber.break", 0);
pref("kmeleon.toolband.Throbber.index", 3);
pref("kmeleon.toolband.Throbber.size", 23);
pref("kmeleon.toolband.Throbber.visibility", false);

pref("kmeleon.toolband.&Zoom Buttons.break", 0);
pref("kmeleon.toolband.&Zoom Buttons.index", 4);
pref("kmeleon.toolband.&Zoom Buttons.size", 59);
pref("kmeleon.toolband.&Zoom Buttons.visibility", true);

pref("kmeleon.toolband.URL Bar.break", 0);
pref("kmeleon.toolband.URL Bar.index", 5);
pref("kmeleon.toolband.URL Bar.size", 574);
pref("kmeleon.toolband.URL Bar.visibility", true);

pref("kmeleon.toolband.&Go Buttons.break", 0);
pref("kmeleon.toolband.&Go Buttons.index", 6);
pref("kmeleon.toolband.&Go Buttons.size", 67);
pref("kmeleon.toolband.&Go Buttons.visibility", true);

pref("kmeleon.toolband.&Save Page As....break", 0);
pref("kmeleon.toolband.&Save Page As....index", 7);
pref("kmeleon.toolband.&Save Page As....size", 40);
pref("kmeleon.toolband.&Save Page As....visibility", false);

pref("kmeleon.toolband.SearchBar Ext.break", 0);
pref("kmeleon.toolband.SearchBar Ext.index", 8);
pref("kmeleon.toolband.SearchBar Ext.size", 253);
pref("kmeleon.toolband.SearchBar Ext.visibility", true);

pref("kmeleon.toolband.Browser Con&figuration.break", 0);
pref("kmeleon.toolband.Browser Con&figuration.index", 9);
pref("kmeleon.toolband.Browser Con&figuration.size", 94);
pref("kmeleon.toolband.Browser Con&figuration.visibility", true);

pref("kmeleon.toolband.Mail/&News Buttons.break", 0);
pref("kmeleon.toolband.Mail/&News Buttons.index", 10);
pref("kmeleon.toolband.Mail/&News Buttons.size", 94);
pref("kmeleon.toolband.Mail/&News Buttons.visibility", false);

pref("kmeleon.toolband.JavaScript &Console.break", 0);
pref("kmeleon.toolband.JavaScript &Console.index", 11);
pref("kmeleon.toolband.JavaScript &Console.size", 67);
pref("kmeleon.toolband.JavaScript &Console.visibility", false);

pref("kmeleon.toolband.&Privacy Bar.break", 1);
pref("kmeleon.toolband.&Privacy Bar.index", 12);
//pref("kmeleon.toolband.&Privacy Bar.size", 1095);
pref("kmeleon.toolband.&Privacy Bar.visibility", true);

pref("kmeleon.toolband.Bookmarks.break", 1);
pref("kmeleon.toolband.Bookmarks.index", 13);
//pref("kmeleon.toolband.Bookmarks.size", 2000);
pref("kmeleon.toolband.Bookmarks.visibility", false);

pref("kmeleon.toolband.&Search+.break", 0);
pref("kmeleon.toolband.&Search+.index", 14);
pref("kmeleon.toolband.&Search+.size", 36);
pref("kmeleon.toolband.&Search+.visibility", true);

pref("kmeleon.toolband.Extensions Manager.break", 0);
pref("kmeleon.toolband.Extensions Manager.index", 15);
pref("kmeleon.toolband.Extensions Manager.size", 36);
pref("kmeleon.toolband.Extensions Manager.visibility", true);

pref("kmeleon.toolband.AdBlock Plus (ABP7).break", 0);
pref("kmeleon.toolband.AdBlock Plus (ABP7).index", 16);
pref("kmeleon.toolband.AdBlock Plus (ABP7).size", 36);
pref("kmeleon.toolband.AdBlock Plus (ABP7).visibility", true);

pref("kmeleon.toolband.Tabs.break", 1);
pref("kmeleon.toolband.Tabs.index", 17);
//pref("kmeleon.toolband.Tabs.size", 1107);
pref("kmeleon.toolband.Tabs.visibility", true);

pref("kmeleon.toolband.Tab/&Window Buttons.break", 0);
pref("kmeleon.toolband.Tab/&Window Buttons.index", 18);
pref("kmeleon.toolband.Tab/&Window Buttons.size", 104);
pref("kmeleon.toolband.Tab/&Window Buttons.visibility", true);

