pref("kmeleon.privacy.useragent.nouseragent", false);

pref("kmeleon.privacy.useragent.Count", 8);
#pref("general.useragent.vendor", "K-Meleon");
#pref("general.useragent.vendorSub", "74.0");

pref("kmeleon.privacy.useragent1.name", "Firefox 38, XP");
pref("kmeleon.privacy.useragent1.sites", "");
pref("kmeleon.privacy.useragent1.string", "Mozilla/5.0 (Windows NT 5.1; rv:38.0) Gecko/20100101 Firefox/38.0");

pref("kmeleon.privacy.useragent2.name", "Firefox 52");
pref("kmeleon.privacy.useragent2.sites", "");
pref("kmeleon.privacy.useragent2.string", "Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0");

pref("kmeleon.privacy.useragent3.name", "MSIE 11");
pref("kmeleon.privacy.useragent3.sites", "");
pref("kmeleon.privacy.useragent3.string", "Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko");

pref("kmeleon.privacy.useragent4.name", "Opera 12");
pref("kmeleon.privacy.useragent4.sites", "");
pref("kmeleon.privacy.useragent4.string", "Opera/9.80 (Windows NT 6.1; U; ru-RU) Presto/2.9.181 Version/12.00");

pref("kmeleon.privacy.useragent5.name", "Chrome 58 Win-x64");
pref("kmeleon.privacy.useragent5.sites", "");
pref("kmeleon.privacy.useragent5.string", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.19 Safari/537.36");

pref("kmeleon.privacy.useragent6.name", "Chrome 58 Mac");
pref("kmeleon.privacy.useragent6.sites", "");
pref("kmeleon.privacy.useragent6.string", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.19 Safari/537.36");

pref("kmeleon.privacy.useragent7.name", "Safari Mac");
pref("kmeleon.privacy.useragent7.sites", "");
pref("kmeleon.privacy.useragent7.string", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/602.2.14 (KHTML, like Gecko) Version/10.0.1 Safari/602.2.14");

pref("kmeleon.privacy.useragent8.name", "K-Meleon 76");
pref("kmeleon.privacy.useragent8.sites", "");
pref("kmeleon.privacy.useragent8.string", "Mozilla/5.0 (Windows NT 5.1; rv:38.0) Gecko/20100101 K-Meleon/76.0");






