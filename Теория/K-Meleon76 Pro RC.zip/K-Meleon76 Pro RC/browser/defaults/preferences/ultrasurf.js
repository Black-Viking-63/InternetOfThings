//ultrasurf default setting
pref("kmeleon.ultrasurf.active", false);
pref("kmeleon.ultrasurf.runcount", 0);