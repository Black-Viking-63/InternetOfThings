//sets html5 media state to fully enabled 

pref("media.fragmented-mp4.enabled", true);
pref("media.fragmented-mp4.exposed", true);
pref("media.windows-media-foundation.enabled", true);
pref("media.windows-media-foundation.play-stand-alone", true);
pref("media.windows-media-foundation.use-dxva", true);
pref("media.mediasource.enabled", true);
pref("media.webm.enabled", true);
pref("media.ogg.enabled", true);
pref("media.wave.enabled", true);
