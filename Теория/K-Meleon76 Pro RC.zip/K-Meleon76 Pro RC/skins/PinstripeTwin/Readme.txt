Installation:

1. Unzip the file (which you've obviously already done :-) ).
2. Copy the 'Pinstripe' folder into C:/Program Files/K-Meleon/skins (presuming thats where
you installed K-meleon to).
3. Go into your K-Meleon preferences and select the Pinstripe skin.
4. Restart K-Meleon and voila!

Tips and Tricks:

There are lots more buttons available!
Open toolbars.cfg in an editor and unhash (delete the #s from) the regions
with the buttons you want. Buttons are available for:
Cut, Copy, Paste, Pop up blocker toggle, New layer and New window.

Small icons are available!
Just rename toolbars.cfg to large_toolbars.cfg then rename small_toolbars.cfg to toolbars.cfg .

Enjoy,

Neil Jenkins

Original theme for Mozilla Firefox by Kevin Gerich