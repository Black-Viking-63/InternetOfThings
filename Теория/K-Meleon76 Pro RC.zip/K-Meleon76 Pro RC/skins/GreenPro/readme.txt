Creative Commons License. You are granted permission to use this skin under that license and you are allowed to further adapt and modify the skin icons provided that you always include this license file in your package.

(c)2010 creative Commons by Lim Chee Aun and Contributors to the K-Meleon project under the GNU General Public License.
-----------------------------------------------------------------

--------------BEGINNING OF LICENSE BLOCK-------------------------------------
Creative Commons


You are free:

* to Share � to copy, distribute and transmit the work
* to Remix � to adapt the work
*

Under the following conditions:

*

Attribution � You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).

Attribute this work:
Information
What does "Attribute this work" mean?
The page you came from contained embedded licensing metadata, including how the creator wishes to be attributed for re-use. You can use the HTML here to cite the work. Doing so will also include metadata on your page so that others can find the original work as well.
*

Noncommercial � You may not use this work for commercial purposes.
*

Share Alike � If you alter, transform, or build upon this work, you may distribute the resulting work only under the same or similar license to this one.

With the understanding that:

* Waiver � Any of the above conditions can be waived if you get permission from the copyright holder.
* Other Rights � In no way are any of the following rights affected by the license:
o Your fair dealing or fair use rights;
o The author's moral rights;
o Rights other persons may have either in the work itself or in how the work is used, such as publicity or privacy rights.

--------------END OF LICENSE BLOCK-------------------------------------
________________________________________________________________

http://cheeaun.com/
http://kmeleon.sourceforge.net/